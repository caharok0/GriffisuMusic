package com.griffisu.music;

import android.Manifest;
import android.app.Activity;
import android.content.ContentUris;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.provider.MediaStore;
import android.view.Gravity;
import android.widget.*;
import android.text.TextWatcher;
import android.text.Editable;
import java.util.*;

public class MainActivity extends Activity {
    private final int bg=Color.rgb(18,18,22), panel=Color.rgb(35,35,43), accent=Color.rgb(190,175,255), fg=Color.rgb(245,242,255);
    private final ArrayList<Track> tracks=new ArrayList<>(); private LinearLayout list; private TextView title,artist,timer; private SeekBar seek;
    private EditText search; private MediaPlayer player; private int current=-1; private boolean seeking=false; private final Handler handler=new Handler();
    static class Track { long id; String title,artist; Uri uri; Track(long i,String t,String a,Uri u){id=i;title=t;artist=a;uri=u;} }
    private int dp(float n){return (int)(n*getResources().getDisplayMetrics().density+.5f);}
    private TextView txt(String s,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;}
    private GradientDrawable shape(int color,int radius){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(radius));return d;}
    private String permission(){return Build.VERSION.SDK_INT>=33?Manifest.permission.READ_MEDIA_AUDIO:Manifest.permission.READ_EXTERNAL_STORAGE;}
    @Override public void onCreate(Bundle b){super.onCreate(b);getWindow().setStatusBarColor(bg);getWindow().setNavigationBarColor(bg);ui();if(Build.VERSION.SDK_INT<23||checkSelfPermission(permission())==PackageManager.PERMISSION_GRANTED)load();else requestPermissions(new String[]{permission()},7);handler.post(tick);}
    private void ui(){
        LinearLayout root=new LinearLayout(this);root.setOrientation(1);root.setPadding(dp(20),dp(18),dp(20),dp(12));root.setBackgroundColor(bg);setContentView(root);
        root.addView(txt("GRIFFISU  ♪",13,accent,true));TextView h=txt("Твоя музыка",30,fg,true);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.topMargin=dp(8);p.bottomMargin=dp(14);root.addView(h,p);
        search=new EditText(this);search.setSingleLine(true);search.setTextColor(fg);search.setHintTextColor(Color.LTGRAY);search.setHint("Поиск песен");search.setTextSize(15);search.setPadding(dp(16),0,dp(16),0);search.setBackground(shape(panel,24));root.addView(search,new LinearLayout.LayoutParams(-1,dp(48)));
        TextView label=txt("БИБЛИОТЕКА",12,accent,true);p=new LinearLayout.LayoutParams(-1,-2);p.topMargin=dp(18);p.bottomMargin=dp(8);root.addView(label,p);
        ScrollView sc=new ScrollView(this);list=new LinearLayout(this);list.setOrientation(1);sc.addView(list);root.addView(sc,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout card=new LinearLayout(this);card.setOrientation(1);card.setPadding(dp(16),dp(13),dp(16),dp(12));card.setBackground(shape(panel,24));p=new LinearLayout.LayoutParams(-1,-2);p.topMargin=dp(12);root.addView(card,p);
        title=txt("Ничего не играет",17,fg,true);artist=txt("Выбери трек из библиотеки",13,Color.LTGRAY,false);card.addView(title);p=new LinearLayout.LayoutParams(-1,-2);p.topMargin=dp(3);card.addView(artist,p);
        seek=new SeekBar(this);seek.setProgressTintList(android.content.res.ColorStateList.valueOf(accent));seek.setThumbTintList(android.content.res.ColorStateList.valueOf(accent));card.addView(seek);timer=txt("00:00 / 00:00",11,Color.LTGRAY,false);card.addView(timer);
        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar s,int v,boolean u){}public void onStartTrackingTouch(SeekBar s){seeking=true;}public void onStopTrackingTouch(SeekBar s){if(player!=null)player.seekTo(s.getProgress());seeking=false;}});
        LinearLayout controls=new LinearLayout(this);controls.setGravity(Gravity.CENTER);Button prev=btn("|◀"),play=btn("▶ / Ⅱ"),next=btn("▶|");controls.addView(prev);controls.addView(play);controls.addView(next);card.addView(controls);
        prev.setOnClickListener(v->playAt(current-1));next.setOnClickListener(v->playAt(current+1));play.setOnClickListener(v->{if(player==null){if(!tracks.isEmpty())playAt(0);}else if(player.isPlaying())player.pause();else player.start();});
        search.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){}public void onTextChanged(CharSequence s,int st,int before,int count){render(s.toString());}public void afterTextChanged(Editable e){}});
    }
    private Button btn(String s){Button b=new Button(this);b.setText(s);b.setTextColor(fg);b.setAllCaps(false);b.setTextSize(13);b.setBackground(shape(Color.rgb(65,57,88),22));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,dp(48),1);p.setMargins(dp(4),dp(8),dp(4),0);b.setLayoutParams(p);return b;}
    private void load(){tracks.clear();Uri base=MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;String[] cols={MediaStore.Audio.Media._ID,MediaStore.Audio.Media.TITLE,MediaStore.Audio.Media.ARTIST};try(Cursor c=getContentResolver().query(base,cols,MediaStore.Audio.Media.IS_MUSIC+" != 0",null,MediaStore.Audio.Media.TITLE+" COLLATE NOCASE ASC")){if(c!=null)while(c.moveToNext()){long id=c.getLong(0);String t=c.getString(1),a=c.getString(2);if(t==null)t="Без названия";if(a==null||a.equals("<unknown>"))a="Неизвестный исполнитель";tracks.add(new Track(id,t,a,ContentUris.withAppendedId(base,id)));}}catch(Exception e){Toast.makeText(this,"Не удалось прочитать музыку",Toast.LENGTH_LONG).show();}render("");if(tracks.isEmpty()){title.setText("Музыка пока не найдена");artist.setText("Добавь аудиофайлы в память телефона");}}
    private void render(String filter){if(list==null)return;list.removeAllViews();String q=filter==null?"":filter.toLowerCase(Locale.ROOT).trim();int n=0;for(int i=0;i<tracks.size();i++){Track t=tracks.get(i);if(!t.title.toLowerCase(Locale.ROOT).contains(q)&&!t.artist.toLowerCase(Locale.ROOT).contains(q))continue;final int ix=i;LinearLayout row=new LinearLayout(this);row.setGravity(Gravity.CENTER_VERTICAL);row.setPadding(dp(12),dp(10),dp(10),dp(10));row.setBackground(shape(current==i?Color.rgb(55,48,73):panel,18));LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,-2);rp.bottomMargin=dp(7);list.addView(row,rp);TextView note=txt("♫",22,accent,true);LinearLayout icon=new LinearLayout(this);icon.setGravity(Gravity.CENTER);icon.setBackground(shape(Color.rgb(70,62,94),14));icon.addView(note);row.addView(icon,new LinearLayout.LayoutParams(dp(46),dp(46)));LinearLayout names=new LinearLayout(this);names.setOrientation(1);names.setPadding(dp(12),0,dp(4),0);row.addView(names,new LinearLayout.LayoutParams(0,-2,1));names.addView(txt(t.title,15,fg,true));names.addView(txt(t.artist,12,Color.LTGRAY,false));row.addView(txt(current==i?"♪":"›",24,accent,true));row.setOnClickListener(v->playAt(ix));n++;}if(n==0){TextView empty=txt(tracks.isEmpty()?"Аудиофайлы не найдены":"Ничего не найдено",14,Color.LTGRAY,false);empty.setPadding(dp(8),dp(20),dp(8),dp(20));list.addView(empty);}}
    private void playAt(int i){if(tracks.isEmpty())return;if(i<0)i=tracks.size()-1;if(i>=tracks.size())i=0;current=i;Track t=tracks.get(i);try{if(player!=null){player.release();player=null;}player=new MediaPlayer();player.setDataSource(this,t.uri);player.setOnPreparedListener(mp->{mp.start();title.setText(t.title);artist.setText(t.artist);seek.setMax(mp.getDuration());timer.setText("00:00 / "+fmt(mp.getDuration()));render(search.getText().toString());});player.setOnCompletionListener(mp->playAt(current+1));player.setOnErrorListener((mp,w,e)->{Toast.makeText(this,"Не удалось воспроизвести файл",Toast.LENGTH_SHORT).show();return true;});player.prepareAsync();}catch(Exception e){Toast.makeText(this,"Ошибка открытия аудиофайла",Toast.LENGTH_SHORT).show();}}
    private String fmt(int ms){int s=Math.max(0,ms)/1000;return String.format(Locale.getDefault(),"%02d:%02d",s/60,s%60);}
    private final Runnable tick=new Runnable(){public void run(){if(player!=null&&!seeking)try{if(player.isPlaying()){seek.setMax(player.getDuration());seek.setProgress(player.getCurrentPosition());timer.setText(fmt(player.getCurrentPosition())+" / "+fmt(player.getDuration()));}}catch(Exception ignored){}handler.postDelayed(this,500);}};
    @Override public void onRequestPermissionsResult(int r,String[] p,int[] g){super.onRequestPermissionsResult(r,p,g);if(r==7){if(g.length>0&&g[0]==PackageManager.PERMISSION_GRANTED)load();else Toast.makeText(this,"Разреши доступ к аудиофайлам",Toast.LENGTH_LONG).show();}}
    @Override protected void onDestroy(){handler.removeCallbacks(tick);if(player!=null){player.release();player=null;}super.onDestroy();}
}
