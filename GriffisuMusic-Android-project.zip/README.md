# Griffisu Music

Android offline music player for Redmi Note 13 Pro.

## Features in v0.1
- Reads local audio through Android MediaStore
- Search by song title and artist
- Play/pause, previous/next, seek bar
- Dark Material-inspired interface
- APK built by GitHub Actions

## Build
Open the Actions tab and run **Build Griffisu Music APK**. After success, download `Griffisu-Music-debug` from Artifacts. The APK is `app-debug.apk`.
